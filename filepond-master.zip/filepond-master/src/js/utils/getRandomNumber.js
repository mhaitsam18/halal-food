export const getRandomNumber = (min = 0, max = 1) =>
    min + Math.random() * (max - min);
