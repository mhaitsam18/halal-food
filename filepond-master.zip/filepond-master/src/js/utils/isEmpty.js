export const isEmpty = value => value == null;
