export const isNumber = value => typeof value === 'number';
